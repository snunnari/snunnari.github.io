******************************************
* Replication Code					 	 *
* "Declared Support and Clientelism" 	 *
* Simeon Nichter and Salvatore Nunnari   *
* Comparative Political Studies      	 *
******************************************

**********************************
* Software: Stata\SE, Version 17 *
**********************************

*****************************************************************************
* Figure 1: Declared Support and Perceived Difficulty of Obtaining Benefits *
*****************************************************************************
ssc install catplot, replace
ssc install estout, replace
use "Data_Survey_Experiment.dta", clear

*Applies Labels to Variables
label define exp_label_1 1 "Declared for Winner" 3 "No Declaration"
label values exp_condition exp_label_1   
label define exp_label_2 2 "Very Easy" 3 "Easy" 4 "Hard" 5 "Very Hard"
label values exp_emp exp_label_2  
label values exp_med exp_label_2
label values exp_agua exp_label_2

*Creates the 3 Subplots in Figure 1 (Combined in Powerpoint)
catplot exp_med exp_condition if exp_med!=-99 & exp_condition!=2, asyvars stack percent(exp_condition) bar(1, bcolor(gs2))  bar(2, bcolor(gs5)) bar(3, bcolor(gs8)) bar(4, bcolor(gs11)) bar(5, bcolor(gs14)) legend(on) title(Medicine) 
catplot exp_agua exp_condition if exp_agua!=-99 & exp_condition!=2, asyvars stack percent(exp_condition) bar(1, bcolor(gs2)) bar(2, bcolor(gs5)) bar(3, bcolor(gs8)) bar(4, bcolor(gs11)) bar(5, bcolor(gs14)) legend(off) title(Water) 
catplot exp_emp exp_condition if exp_emp!=-99 & exp_condition!=2, asyvars stack percent(exp_condition) bar(1, bcolor(gs2)) bar(2, bcolor(gs5)) bar(3, bcolor(gs8)) bar(4, bcolor(gs11)) bar(5, bcolor(gs14)) legend(off) title(Employment) 

***********************************************************************************************************************
* Codebook for Treatments: 																							  *	
* T1=NO CLIENTELISM; T2=BASELINE CLIENTELISM; T3=LOPSIDED ELECTION; T4=LOW MONITORING; T5=CLIENTELISM AND PUNISHMENT; *
* T6=PUNISHMENT ONLY; T7=NO ELECTION INFLUENCE; T8=COMPETITIVE CLIENTELISM; T9=EXPRESSIVE UTILITY; T10=COST           *
***********************************************************************************************************************

**************************************************************
* Figure 3: Declaration Choice of Participants, by Treatment *
**************************************************************
use "Data_Long.dta", clear
keep if finished_experiment == 1

bysort pt treatment: egen m_declaremachine=mean(declaremachine)
bysort pt treatment: egen m_declareopposition=mean(declareopposition)
bysort pt treatment: egen m_undeclared=mean(undeclared)

*Applies Treatment Labels to Treatment Variable
label define treatmentlabel 1 "No Clientelism" 2 "Baseline Clientelism" 3 "Lopsided Election" 4 "Low Monitoring" 5 "Clientelism & Punish" 6 "Punishment Only" 7 "No Election Influence" 8 "Competitive Clientelism" 9 "Expressive Utility" 10 "Cost", replace
label values treatment treatmentlabel

label define ptlabel 1 "Strong Supporter" 2 "Supporter" 3 "Weak Supporter" 4 "Indifferent" 5 "Weak Opposer" 6 "Opposer" 7 "Strong Opposer"
label values pt ptlabel

*Create and Label Reordered Treatment Variable (For Consistency with Tables) 
recode treatment (1=2) (2=1) (3=3) (4=5) (5=8) (6=7) (7=10) (8=6) (9=9) (10=4), gen(treatment_graph_reorder)
label define treatmentlabel_reorder 1 "Baseline Clientelism" 2 "No Clientelism" 3 "Lopsided Election" 4 "Cost" 5 "Low Monitoring" 6 "Competitive Clientelism" 7 "Punishment Only" 8 "Clientelism & Punish" 9 "Expressive Utility" 10 "No Election Influence", replace
label values treatment_graph_reorder treatmentlabel_reorder 

*Create Figure 3
twoway (line m_declaremachine pt, lcolor(blue) lwidth(thick) lpattern(solid)) (line m_declareopposition pt, lcolor(red) lwidth(thick) lpattern(shortdash)) (line m_undeclared pt, lcolor(black) lwidth(thick) lpattern(dash_dot)), ytitle(Share of Choices) ytitle(, size(small)) ylabel(#7, labsize(small)) xtitle(Partisan Type) xtitle(, size(small)) xscale(line extend fextend) xlabel(1 "1" 2 "2" 3 "3" 4 "4" 5 "5" 6 "6" 7 "7", labels labsize(small) angle(horizontal) valuelabel ticks) by(, legend(on)) legend(order(1 "Declare for A" 2 "Declare for B" 3 "No Declaration") note(, nobox) size(small) row(1)) by(treatment_graph_reorder, rows(2) iyaxes ixaxes iytick ixtick iylabel ixlabel iytitle ixtitle) subtitle(, size(small)) scheme(s1mono)
	
*********************************************
* Table 4: Declaration Choices by Treatment *
*********************************************
use "Data_Wide.dta", clear
keep if finished_experiment == 1

forvalues i=1/10 {
gen t`i'machine = 0 
replace t`i'machine = 1 if t`i'choice == 1
}

forvalues i=1/10 {
gen t`i'opposition = 0 
replace t`i'opposition = 1 if t`i'choice == 2
}
 
forvalues i=1/10 {
gen t`i'undeclared = 0 
replace t`i'undeclared = 1 if t`i'choice == 0
} 

* Panel A: Declaration for Clientelist Candidate A
prtest t1machine == t2machine
prtest t3machine == t2machine
prtest t10machine == t2machine
prtest t4machine == t2machine
prtest t6machine == t1machine
prtest t5machine == t6machine
prtest t8machine == t2machine
prtest t9machine == t2machine
prtest t7machine == t2machine

* Panel B: Declaration for Opposition Candidate B
prtest t1opposition == t2opposition
prtest t3opposition == t2opposition
prtest t10opposition == t2opposition
prtest t4opposition == t2opposition
prtest t6opposition == t1opposition
prtest t5opposition == t6opposition
prtest t8opposition == t2opposition
prtest t9opposition == t2opposition
prtest t7opposition == t2opposition

* Panel C: No Declaration
prtest t1undeclared == t2undeclared
prtest t3undeclared == t2undeclared
prtest t10undeclared == t2undeclared
prtest t4undeclared == t2undeclared
prtest t6undeclared == t1undeclared
prtest t5undeclared == t6undeclared
prtest t8undeclared == t2undeclared
prtest t9undeclared == t2undeclared
prtest t7undeclared == t2undeclared

********************************************************************
* Table 5: Estimates of Average Treatment Effects, Rewards (Logit) *
********************************************************************
use "Data_Long.dta", clear
keep if finished_experiment == 1

set more off
*net install st0085_2.pkg
eststo clear
quietly logit declaremachine ib2.treatment round pt_num screener if treatment!=5 & treatment!=6, robust cluster(id)
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round pt_num screener (asobserved) 1.treatment 3.treatment 4.treatment 9.treatment 7.treatment 8.treatment 10.treatment round pt_num screener) post 
quietly logit declaremachine ib2.treatment round i.id if treatment!=5 & treatment!=6, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 1.treatment 3.treatment 10.treatment 4.treatment 9.treatment 7.treatment 8.treatment round) post 
quietly logit declareopposition ib2.treatment round pt_num screener if treatment!=5 & treatment!=6, robust cluster(id)
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round pt_num screener (asobserved) 1.treatment 3.treatment 10.treatment 4.treatment 9.treatment 7.treatment 8.treatment  round pt_num screener) post 
quietly logit declareopposition ib2.treatment round i.id if treatment!=5 & treatment!=6, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 1.treatment 3.treatment 10.treatment 4.treatment 9.treatment 7.treatment 8.treatment round) post 
quietly logit undeclared ib2.treatment round pt_num screener if treatment!=5 & treatment!=6, robust cluster(id)
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round pt_num screener (asobserved) 1.treatment 3.treatment 10.treatment 4.treatment 9.treatment 7.treatment 8.treatment round pt_num screener) post 
quietly logit undeclared ib2.treatment round i.id if treatment!=5 & treatment!=6, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 1.treatment 3.treatment 10.treatment 4.treatment 9.treatment 7.treatment 8.treatment round) post 
esttab est1 est2 est3 est4 est5 est6, star(* 0.05 ** 0.01) se b(3) margin keep(1.treatment 3.treatment 10.treatment 4.treatment 8.treatment 9.treatment 7.treatment round pt_num screener) order(1.treatment 3.treatment 10.treatment 4.treatment 8.treatment 9.treatment 7.treatment round pt_num screener)

****************************************************************************
* Table 6: Estimates of Average Treatment Effects, Punishment Only (Logit) *
****************************************************************************
eststo clear
quietly logit declaremachine ib1.treatment round pt_num screener if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=5 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round (asobserved) 6.treatment round pt_num screener) post 
quietly logit declaremachine ib1.treatment round i.id if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=5 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 6.treatment round) post 
quietly logit declareopposition ib1.treatment round pt_num screener if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=5 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round (asobserved) 6.treatment round pt_num screener) post 
quietly logit declareopposition ib1.treatment round i.id if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=5 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 6.treatment round) post 
quietly logit undeclared ib1.treatment round pt_num screener if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=5 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round (asobserved) 6.treatment round pt_num screener) post 
quietly logit undeclared ib1.treatment round i.id if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=5 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 6.treatment round) post 
esttab est1 est2 est3 est4 est5 est6, star(* 0.05 ** 0.01) se b(3) margin keep(6.treatment round pt_num screener) order(6.treatment round pt_num screener)

*************************************************************************************
* Table 7: Estimates of Average Treatment Effects, Clientelism & Punishment (Logit) *                                   
*************************************************************************************
eststo clear
quietly logit declaremachine ib6.treatment round pt_num screener if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=1 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round (asobserved) 5.treatment round pt_num screener) post 
quietly logit declaremachine ib6.treatment round i.id if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=1 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 5.treatment round) post 
quietly logit declareopposition ib6.treatment round pt_num screener if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=1 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round (asobserved) 5.treatment round pt_num screener) post 
quietly logit declareopposition ib6.treatment round i.id if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=1 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 5.treatment round) post 
quietly logit undeclared ib6.treatment round pt_num screener if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=1 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round pt_num screener) at((means) round (asobserved) 5.treatment round pt_num screener) post 
quietly logit undeclared ib6.treatment round i.id if treatment!=2 & treatment!=3 & treatment!=4 & treatment!=1 & treatment!=7 & treatment!=8 & treatment!=9 & treatment!=10, robust
eststo: quietly margins, dydx(treatment round) at((means) round (asobserved) 5.treatment round) post 
esttab est1 est2 est3 est4 est5 est6, star(* 0.05 ** 0.01) se b(3) margin keep(5.treatment round pt_num screener) order(5.treatment round pt_num screener)
