Table of Contents
final_tables_revision.do (do file to produce all tables)
tables_final_revision.dta (dta file to produce all tables, but table 1)
districts_all.dta (dta file to produce table 1)

Notes on Tables
Table 1 (Share of Swing and Safe Districts): use final_tables_revision.do and districts_all.dta
Table 2 (Unemployment Rate in Swing and Safe Districts): use final_tables_revision.do and tables_final_revision.dta
Table 3 (Differences in Unemployment Rates in Swing and Safe Districts): use final_tables_revision.do and tables_final_revision.dta
Table 4 (Summary Statistics): use final_tables_revision.do and tables_final_revision.dta
Table 5 (Results on Unemployment Benefit Generosity (with Country FE)): use final_tables_revision.do and tables_final_revision.dta
Table 6 (Results on Unemployment Benefit Generosity (without Country FE)): use final_tables_revision.do and tables_final_revision.dta
Table 7 (Results on Unemployment Benefit Generosity -- Elasticities (with Country FE)): use final_tables_revision.do and tables_final_revision.dta
Table 8 (Results on Unemployment Benefit Generosity -- Elasticities (without Country FE)): use final_tables_revision.do and tables_final_revision.dta
Table 9 (Results of Placebo with Social Security Generosity): use final_tables_revision.do and tables_final_revision.dta
Table 10 (Results of Placebo with Social Security Generosity): use final_tables_revision.do and tables_final_revision.dta

Table A.2 (Results on Unemployment Benefit Generosity (using the Strict Measure)): use final_tables_revision.do and tables_final_revision.dta
Table A.3 (Results on Unemployment Benefit Generosity (using the Median Measure)): use final_tables_revision.do and tables_final_revision.dta
Table A.4 (Results on Unemployment Benefit Generosity -- Elasticities (using the Strict Measure)): use final_tables_revision.do and tables_final_revision.dta
Table A.5 (Results on Unemployment Benefit Generosity -- Elasticities (using the Median Measure)): use final_tables_revision.do and tables_final_revision.dta

Base Software Dependencies: Stata 15
