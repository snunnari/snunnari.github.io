# Experimental Software for "Audi Alteram Partem: An Experiment on Selective Exposure to Information"

This folder contains the [oTree](https://www.otree.org/) app used to collect the data for:

> Nunnari, Salvatore and Giovanni Montanari (2025). "Audi Alteram Partem: An Experiment on Selective Exposure to Information." *Journal of the Economic Science Association*, 11, 139–150. [doi:10.1017/esa.2025.8](https://doi.org/10.1017/esa.2025.8)

A copy of the paper is available [here](https://snunnari.github.io/mn_selectexposure.pdf).

## Overview

The experiment studies **endogenous information acquisition and selective exposure**. A decision maker wants to learn about an uncertain state of the world and can acquire a signal from one of **two information sources** that have opposite biases: when informed about the state, a source reports it truthfully; when uninformed, it reports its favorite state. A Bayesian decision maker is better off seeking *confirmatory* information unless the source biased against the prior is sufficiently reliable. The experiment manipulates the **prior** over the state and the **relative reliability** of the two sources to test whether subjects' demand for (dis)confirmatory information matches the normative benchmark.

### Task

In each round a subject faces an urn with `BLUE` and `RED` balls. A ball is drawn; the prior probability that it is `BLUE` is π. The subject chooses which of two experts — a **BLUE Expert** or a **RED Expert** — to consult, observes that expert's message, guesses the ball's color, and reports their confidence. One round, drawn at random, determines payment: a correct guess earns the prize, an incorrect guess earns nothing.

### Treatments

Parameters live in `information_acquisition/models.py` (`Constants`). Treatments are assigned **between subjects**, cycled across participants. The conditions actually fielded are `T1`, `T2`, `T4`, `T5`:

| Treatment | Prior π(BLUE) | Source Bias (λ_b, λ_r) | Reliability |
|-----------|---------------|-----------------------------------|-------------|
| T1 | 0.8 | (0.5, 0.5) | Symmetric |
| T2 | 0.8 | (0.7, 0.3) | Asymmetric |
| T4 | 0.6 | (0.5, 0.5) | Symmetric |
| T5 | 0.6 | (0.7, 0.3) | Asymmetric |

(`T3`/`T6` with a third reliability level, λ = (0.9, 0.1), are defined in the code but were not fielded.)

### Page flow

`Prolific_ID → Welcome → Instructions → Feedback1 → Instructions2 → Feedback2 → Instructions3 → Feedback3 → Instructions4 → Signal → Choice → Results → Final`

Instruction pages and comprehension checks (`Feedback1–3`) appear in the first round; the decision pages (`Signal → Choice → Results`) repeat across all `num_rounds = 5` rounds.

## Repository structure

```
information_acquisition/      # the experimental app
  models.py                   # Constants, treatments, signal-generation logic, payoffs
  views.py                    # page classes and page_sequence
  templates/                  # instructions, decision screens, feedback
  static/                     # urn and expert images
settings.py                   # oTree session configs and rooms
requirements.txt              # runtime dependencies
runtime.txt                   # Python version (for Heroku)
Procfile                      # Heroku production process definition
```

## Requirements

- Python 3.8
- `otree==3.3.11` (this app is not compatible with oTree 5+)
- `scipy` (used to draw Bernoulli random variables for stimulus generation; any recent version compatible with Python 3.8 works)

`requirements.txt` also lists `psycopg2`, the PostgreSQL driver for deployment on a cloud server, which is not needed locally, where oTree uses SQLite by default.

## Running locally

### 1. Create the environment

```bash
conda create -n otree_3 python=3.8
conda activate otree_3
pip install otree==3.3.11 scipy
```

### 2. Launch the dev server

```bash
otree devserver
```

Then open <http://localhost:8000> and go to **Demo → Information Acquisition**.

> If you hit a "table already exists" error, delete `db.sqlite3` and rerun `otree devserver`.

### 3. Test the full app with bots (optional)

`information_acquisition/tests.py` defines an oTree `PlayerBot` that plays a
participant through the entire page sequence for all `num_rounds` rounds. Run:

```bash
otree test information_acquisition
```

A zero exit status means every page (intro, comprehension checks, signal,
choice, results, and final) renders and validates end to end for all demo
participants. The bot alternates the consulted expert across rounds so both
payoff branches are exercised.

## Deployment (production)

The original experiment ran on Heroku. The `Procfile` and `runtime.txt` configure that deployment, which expects PostgreSQL and Redis via environment variables, plus:

- `OTREE_ADMIN_PASSWORD` — admin-area password
- `OTREE_PRODUCTION=1` — production mode

