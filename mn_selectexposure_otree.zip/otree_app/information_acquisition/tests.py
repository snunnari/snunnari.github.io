from otree.api import Submission
from . import views
from ._builtin import Bot
from .models import Constants


class PlayerBot(Bot):
    """Plays one participant through the full experiment.

    Run with:  otree test information_acquisition

    The bot submits valid values for every displayed page across all
    ``Constants.num_rounds`` rounds and asserts the whole page sequence
    completes without error. To exercise both payoff branches it alternates
    the consulted expert by round (BLUE on odd rounds, RED on even rounds).
    """

    def play_round(self):
        # --- Round-1-only pages: intro + comprehension checks ---------------
        # The comprehension questions are answered on the Instructions pages;
        # the Feedback pages only display whether the answer was correct.
        if self.round_number == 1:
            yield Submission(views.Prolific_ID, {'pa_id': 'bot_test'})
            yield views.Welcome
            yield Submission(views.Instructions, {'feedback1': 'answer1'})
            yield views.Feedback1
            yield Submission(views.Instructions2, {'feedback2': 'answer1'})
            yield views.Feedback2
            yield Submission(views.Instructions3, {'feedback3': 'answer1'})
            yield views.Feedback3
            yield views.Instructions4

        # --- Every-round decision pages -------------------------------------
        expert = 'BLUE Expert' if self.round_number % 2 == 1 else 'RED Expert'
        yield Submission(views.Signal, {'expert_choice': expert})

        # All four fields are required regardless of the expert consulted.
        yield Submission(views.Choice, {
            'confidence_b': 50,
            'confidence_r': 50,
            'ball_choice_b': 'BLUE',
            'ball_choice_r': 'RED',
        })
        yield views.Results

        # --- Terminal page (last round only) --------------------------------
        # Final is the end-of-experiment "thank you" page; it has no Next
        # button, so disable the bot's submit-button check.
        if self.round_number == Constants.num_rounds:
            yield Submission(views.Final, check_html=False)
