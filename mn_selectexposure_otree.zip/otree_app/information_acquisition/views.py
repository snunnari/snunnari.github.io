from otree.api import Currency as c, currency_range
from . import models
from ._builtin import Page, WaitPage
from .models import Constants
from math import ceil


class Prolific_ID(Page):
    form_model = models.Player
    form_fields = ['pa_id']

    def is_displayed(self):
        return self.subsession.round_number == 1


class Welcome(Page):
    def is_displayed(self):
        return self.subsession.round_number == 1


class Introduction(Page):
    def vars_for_template(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            return {'n1_balls': int(Constants.pi1 * Constants.total),
                    'n2_balls': int(Constants.c_pi1 * Constants.total)
                    }
        else:
            return {'n1_balls': int(Constants.pi2 * Constants.total),
                    'n2_balls': int(Constants.c_pi2 * Constants.total)
                    }

    def is_displayed(self):
        return self.subsession.round_number == 1


class Instructions(Page):
    def vars_for_template(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            if self.participant.vars['treatment'] == 'T1':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T2':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5' or self.participant.vars['treatment'] == 'T6':
            if self.participant.vars['treatment'] == 'T4':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T5':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }

    def is_displayed(self):
        return self.subsession.round_number == 1

    form_model = models.Player
    form_fields = ['feedback1']


class Instructions2(Page):
    def vars_for_template(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            if self.participant.vars['treatment'] == 'T1':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T2':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5' or self.participant.vars['treatment'] == 'T6':
            if self.participant.vars['treatment'] == 'T4':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T5':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }

    def is_displayed(self):
        return self.subsession.round_number == 1

    form_model = models.Player
    form_fields = ['feedback2']


class Instructions3(Page):
    def vars_for_template(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            if self.participant.vars['treatment'] == 'T1':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T2':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5' or self.participant.vars['treatment'] == 'T6':
            if self.participant.vars['treatment'] == 'T4':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T5':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }

    def is_displayed(self):
        return self.subsession.round_number == 1

    form_model = models.Player
    form_fields = ['feedback3']


class Signal(Page):
    form_model = models.Player
    form_fields = ['expert_choice']

    def vars_for_template(self):
        round_history = []

        for me_prev_round in self.player.in_previous_rounds():
            if me_prev_round.expert_choice == "BLUE Expert":
                round_history.append({
                    'round_number': me_prev_round.round_number,
                    'newspaper': me_prev_round.expert_choice,
                    'signal': me_prev_round.message_b,
                    'real_colour': me_prev_round.ball_colour
                })
            else:
                round_history.append({
                    'round_number': me_prev_round.round_number,
                    'newspaper': me_prev_round.expert_choice,
                    'signal': me_prev_round.message_r,
                    'real_colour': me_prev_round.ball_colour
                })

        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2':
            if self.participant.vars['treatment'] == 'T1':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1,
                        'round_history': round_history
                        }
            else:
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2,
                        'round_history': round_history
                        }
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5':
            if self.participant.vars['treatment'] == 'T4':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1,
                        'round_history': round_history
                        }
            else:
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2,
                        'round_history': round_history
                        }


class Choice(Page):
    form_model = models.Player
    form_fields = ['confidence_b', 'confidence_r', 'ball_choice_b', 'ball_choice_r']

    def vars_for_template(self):

        round_history = []

        for me_prev_round in self.player.in_previous_rounds():
            if me_prev_round.expert_choice == "BLUE Expert":
                round_history.append({
                    'round_number': me_prev_round.round_number,
                    'newspaper': me_prev_round.expert_choice,
                    'signal': me_prev_round.message_b,
                    'real_colour': me_prev_round.ball_colour
                })
            else:
                round_history.append({
                    'round_number': me_prev_round.round_number,
                    'newspaper': me_prev_round.expert_choice,
                    'signal': me_prev_round.message_r,
                    'real_colour': me_prev_round.ball_colour
                })

        return {
            'round_history': round_history
        }

    def before_next_page(self):
        self.player.set_payoff()


class Results(Page):
    def vars_for_template(self):
        return {
            'paying_round': self.session.vars['paying_round']
        }


class Final(Page):
    def is_displayed(self):
        return self.subsession.round_number == Constants.num_rounds


class Feedback1(Page):
    def is_displayed(self):
        return self.subsession.round_number == 1

    def vars_for_template(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            if self.participant.vars['treatment'] == 'T1':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T2':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5' or self.participant.vars['treatment'] == 'T6':
            if self.participant.vars['treatment'] == 'T4':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T5':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }


class Feedback2(Page):
    def is_displayed(self):
        return self.subsession.round_number == 1

    def vars_for_template(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            if self.participant.vars['treatment'] == 'T1':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T2':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5' or self.participant.vars['treatment'] == 'T6':
            if self.participant.vars['treatment'] == 'T4':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T5':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }


class Feedback3(Page):
    def is_displayed(self):
        return self.subsession.round_number == 1

    def vars_for_template(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            if self.participant.vars['treatment'] == 'T1':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T2':
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi1 * Constants.total),
                        'n2_balls': int(Constants.c_pi1 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5' or self.participant.vars['treatment'] == 'T6':
            if self.participant.vars['treatment'] == 'T4':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_1),
                        'complement_r': (1 - Constants.lambda_r_1),
                        'lambda_b': Constants.lambda_b_1,
                        'lambda_r': Constants.lambda_r_1
                        }
            elif self.participant.vars['treatment'] == 'T5':
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_2),
                        'complement_r': (1 - Constants.lambda_r_2),
                        'lambda_b': Constants.lambda_b_2,
                        'lambda_r': Constants.lambda_r_2
                        }
            else:
                return {'n1_balls': int(Constants.pi2 * Constants.total),
                        'n2_balls': int(Constants.c_pi2 * Constants.total),
                        'complement_b': (1 - Constants.lambda_b_3),
                        'complement_r': (1 - Constants.lambda_r_3),
                        'lambda_b': Constants.lambda_b_3,
                        'lambda_r': Constants.lambda_r_3
                        }


class Instructions4(Page):
        def is_displayed(self):
            return self.subsession.round_number == 1

        def vars_for_template(self):
            if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or \
                            self.participant.vars['treatment'] == 'T3':
                if self.participant.vars['treatment'] == 'T1':
                    return {'n1_balls': int(Constants.pi1 * Constants.total),
                            'n2_balls': int(Constants.c_pi1 * Constants.total),
                            'complement_b': (1 - Constants.lambda_b_1),
                            'complement_r': (1 - Constants.lambda_r_1),
                            'lambda_b': Constants.lambda_b_1,
                            'lambda_r': Constants.lambda_r_1
                            }
                elif self.participant.vars['treatment'] == 'T2':
                    return {'n1_balls': int(Constants.pi1 * Constants.total),
                            'n2_balls': int(Constants.c_pi1 * Constants.total),
                            'complement_b': (1 - Constants.lambda_b_2),
                            'complement_r': (1 - Constants.lambda_r_2),
                            'lambda_b': Constants.lambda_b_2,
                            'lambda_r': Constants.lambda_r_2
                            }
                else:
                    return {'n1_balls': int(Constants.pi1 * Constants.total),
                            'n2_balls': int(Constants.c_pi1 * Constants.total),
                            'complement_b': (1 - Constants.lambda_b_3),
                            'complement_r': (1 - Constants.lambda_r_3),
                            'lambda_b': Constants.lambda_b_3,
                            'lambda_r': Constants.lambda_r_3
                            }
            elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5' or \
                            self.participant.vars['treatment'] == 'T6':
                if self.participant.vars['treatment'] == 'T4':
                    return {'n1_balls': int(Constants.pi2 * Constants.total),
                            'n2_balls': int(Constants.c_pi2 * Constants.total),
                            'complement_b': (1 - Constants.lambda_b_1),
                            'complement_r': (1 - Constants.lambda_r_1),
                            'lambda_b': Constants.lambda_b_1,
                            'lambda_r': Constants.lambda_r_1
                            }
                elif self.participant.vars['treatment'] == 'T5':
                    return {'n1_balls': int(Constants.pi2 * Constants.total),
                            'n2_balls': int(Constants.c_pi2 * Constants.total),
                            'complement_b': (1 - Constants.lambda_b_2),
                            'complement_r': (1 - Constants.lambda_r_2),
                            'lambda_b': Constants.lambda_b_2,
                            'lambda_r': Constants.lambda_r_2
                            }
                else:
                    return {'n1_balls': int(Constants.pi2 * Constants.total),
                            'n2_balls': int(Constants.c_pi2 * Constants.total),
                            'complement_b': (1 - Constants.lambda_b_3),
                            'complement_r': (1 - Constants.lambda_r_3),
                            'lambda_b': Constants.lambda_b_3,
                            'lambda_r': Constants.lambda_r_3
                            }


page_sequence = [
    Prolific_ID,
    Welcome,
    Instructions,
    Feedback1,
    Instructions2,
    Feedback2,
    Instructions3,
    Feedback3,
    Instructions4,
    Signal,
    Choice,
    Results,
    Final
]