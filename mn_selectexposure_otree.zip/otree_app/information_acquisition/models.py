from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)

from scipy.stats import bernoulli
import random
from math import ceil
import itertools

author = 'Giovanni Montanari'

doc = """
This experiment tests endogenous information acquisition from two different information structures as predicted by Bayesian rationality.
We envisaged six treatments, depending on the parameters characterising the problem. See paper for further details. 
"""


class Constants(BaseConstants):
    name_in_url = 'information_acquisition'
    players_per_group = None
    num_rounds = 5

    colours = ['BLUE', 'RED']  # balls colours; the order matters, as pi refers to the first colour
    colour1 = colours[0]  # define this only for template purposes
    colour2 = colours[1] # define this only for template purposes
    total = 10  # define the total number of balls in the urn, for template purposes
    payoff_win = 1  # agent's payoff when she correctly guesses the colour of the ball
    payoff_lose = 0  # agent's payoff when she mistakes the colour of the ball
    pi1 = 0.8
    pi2 = 0.6
    c_pi1 = 0.2
    c_pi2 = 0.4
    lambda_b_1 = 0.5
    lambda_b_2 = 0.7
    lambda_b_3 = 0.9
    lambda_r_1 = 0.5
    lambda_r_2 = 0.3
    lambda_r_3 = 0.1


class Subsession(BaseSubsession):

    def creating_session(self):
        if self.round_number == 1:
            paying_round = random.randint(1, Constants.num_rounds)
            self.session.vars['paying_round'] = paying_round
            treatments = itertools.cycle(['T1', 'T2', 'T4', 'T5'])
            for player in self.get_players():
                player.participant.vars['treatment'] = next(treatments)
        for player in self.get_players():
            player.treatment = player.participant.vars['treatment']
            player.ball_colour = player.random_colour()
            player.message_b = player.messenger_b()
            player.message_r = player.messenger_r()



class Group(BaseGroup):
    pass


class Player(BasePlayer):
    treatment = models.CharField()
    ball_colour = models.CharField()
    message_b = models.CharField()
    message_r = models.CharField()
    pa_id = models.TextField()
    feedback1 = models.CharField(choices=['answer1', 'answer2', 'answer3'])
    feedback2 = models.CharField(choices=['answer1', 'answer2', 'answer3', 'answer4'])
    feedback3 = models.CharField(choices=['answer1', 'answer2', 'answer3'])
    probability = models.IntegerField()

    def creating_session(self):
        if self.round_number != 1:
            for p in self.in_rounds(2,Constants.num_rounds):
                p.pa_id = p.in_round(1).pa_id

    expert_choice = models.CharField(
        choices=['BLUE Expert', 'RED Expert'],
        widget=widgets.RadioSelectHorizontal()
    )

    ball_choice_b = models.CharField(
        choices=['BLUE', 'RED'],
        widget=widgets.RadioSelectHorizontal()
    )

    ball_choice_r = models.CharField(
        choices=['BLUE', 'RED'],
        widget=widgets.RadioSelectHorizontal()
    )

    confidence_b = models.PositiveIntegerField(
        #widget=widgets.SliderInput(attrs={'step': '1'})
        min=0,
        max=100
    )

    confidence_r = models.PositiveIntegerField(
        # widget=widgets.SliderInput(attrs={'step': '1'})
        min=0,
        max=100
    )

    def random_colour(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T3':
            if bernoulli.rvs(Constants.pi1):
                return Constants.colours[0]
            else:
                return Constants.colours[1]
        else:
            if bernoulli.rvs(Constants.pi2):
                return Constants.colours[0]
            else:
                return Constants.colours[1]

    def messenger_b(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T4':
            if bernoulli.rvs(1 - Constants.lambda_b_1):
                return self.ball_colour
            else:
                return Constants.colours[0]
        elif self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T5':
            if bernoulli.rvs(1 - Constants.lambda_b_2):
                return self.ball_colour
            else:
                return Constants.colours[0]
        elif self.participant.vars['treatment'] == 'T3' or self.participant.vars['treatment'] == 'T6':
            if bernoulli.rvs(1 - Constants.lambda_b_3):
                return self.ball_colour
            else:
                return Constants.colours[0]

    def messenger_r(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T4':
            if bernoulli.rvs(1 - Constants.lambda_r_1):
                return self.ball_colour
            else:
                return Constants.colours[1]
        elif self.participant.vars['treatment'] == 'T2' or self.participant.vars['treatment'] == 'T5':
            if bernoulli.rvs(1 - Constants.lambda_r_2):
                return self.ball_colour
            else:
                return Constants.colours[1]
        elif self.participant.vars['treatment'] == 'T3' or self.participant.vars['treatment'] == 'T6':
            if bernoulli.rvs(1 - Constants.lambda_r_3):
                return self.ball_colour
            else:
                return Constants.colours[1]

    def set_pa(self):
        if self.participant.vars['treatment'] == 'T1' or self.participant.vars['treatment'] == 'T2':
            pi = Constants.pi1
            if self.participant.vars['treatment'] == 'T1':
                lambda_b = Constants.lambda_b_1
                lambda_r = Constants.lambda_r_1
            else:
                lambda_b = Constants.lambda_b_2
                lambda_r = Constants.lambda_r_2
        elif self.participant.vars['treatment'] == 'T4' or self.participant.vars['treatment'] == 'T5':
            pi = Constants.pi2
            if self.participant.vars['treatment'] == 'T4':
                lambda_b = Constants.lambda_b_1
                lambda_r = Constants.lambda_r_1
            else:
                lambda_b = Constants.lambda_b_2
                lambda_r = Constants.lambda_r_2
        if self.expert_choice == 'BLUE Expert':
            if self.message_b == "BLUE":
                return pi / (lambda_b + pi * (1 - lambda_b))
            else:
                return 0
        if self.expert_choice == 'RED Expert':
            if self.message_r == "BLUE":
                return 1
            else:
                return (pi * lambda_r) / (1 - (1 - lambda_r) * pi)

    def set_payoff(self):
        if self.expert_choice == 'BLUE Expert':
           if self.message_b == 'BLUE':
                bonus = (self.ball_choice_b == self.ball_colour)
           else:
               bonus = (self.ball_choice_r == self.ball_colour)
        else:
            if self.message_r == 'BLUE':
                bonus = (self.ball_choice_b == self.ball_colour)
            else:
                bonus = (self.ball_choice_r == self.ball_colour)

        self.payoff = c(bonus)

        if self.subsession.round_number == Constants.num_rounds and self.session.vars['paying_round'] != self.subsession.round_number:
            self.payoff = self.in_round(self.session.vars['paying_round']).payoff
            for p in self.in_previous_rounds():
                p.payoff = 0
            for p in self.in_all_rounds():
                p.pa_id = p.in_round(1).pa_id

        if self.subsession.round_number == Constants.num_rounds and self.session.vars['paying_round'] == self.subsession.round_number:
            self.payoff = c(bonus)
            for p in self.in_previous_rounds():
                p.payoff = 0
            for p in self.in_all_rounds():
                p.pa_id = p.in_round(1).pa_id