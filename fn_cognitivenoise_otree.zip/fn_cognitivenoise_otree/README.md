# Experimental Software

This package contains the [oTree](https://www.otree.org) software used to run the
experiments in:

> Cary Frydman and Salvatore Nunnari, "Coordination with Cognitive Noise."

The software is organized as **three independent oTree projects**, one per experiment.
Each folder has its own `README.md` with the full experiment description, parameters, file
layout, and run instructions.

## Contents

| Folder | Experiment in the paper | oTree app(s) | Session config |
|--------|-------------------------|--------------|----------------|
| `otree_cognoise_human/` | **Experiment 1** — Human vs Human Game (Sections 3–4) | `exp1` | `exp1` |
| `otree_cognoise_algorithm/` | **Experiment 2** — Human vs Algorithm Game (Section 5) | `exp2` | `exp2` |
| `otree_cognoise_perception/` | **Online Appendix Experiment** — Perceptual Discrimination Task | `p1_one`, `p2_one` | `one_v2` |

## Requirements (shared by all three projects)

- **Python 3.8** 
- **oTree 3.3.11** — These projects are **not** compatible with oTree 5+.
- **numpy** — used by the perception app at runtime and by the stimulus-generation scripts.

### Create the environment once

```bash
conda create -n cognoise-otree3 python=3.8
conda activate cognoise-otree3
pip install otree==3.3.11 numpy
```

(or the equivalent with `python3.8 -m venv`). The same environment runs all three projects.

## Running a project (local deployment)

The instructions below deploy a project on your **local machine**. For the actual data collection, each
project was hosted on an **online server** (in our case, Heroku); the `Procfile` and
`runtime.txt` files included in each project are the configuration for that cloud
deployment.

To run one experiment locally, activate the environment, change into its folder, and start
the development server:

```bash
cd otree_cognoise_human          # or otree_cognoise_algorithm, or otree_cognoise_perception
otree devserver
```

Then open <http://localhost:8000> and start the project's session (the session-config name
is in the table above). To verify that a project installs and runs correctly, use its bot
test — for example `otree test exp1` — which sends bots through the entire experiment and
should finish with `Bots completed session`. The exact test command for each project is in
its own README.

> If `otree devserver` reports a database error on first run, delete `db.sqlite3` (if
> present) and start it again; do not run `otree resetdb` immediately before `devserver`.
