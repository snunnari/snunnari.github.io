"""
Generate the random sequences of numbers shown to participants in the discrimination
task (app p1_one) of the Online Appendix experiment in Frydman and Nunnari,
"Coordination with Cognitive Noise."

Each of 200 potential participants is assigned an independent sequence of 150 integer
numbers. Odd-numbered participants receive a high-volatility sequence and even-numbered
participants a low-volatility sequence (the assignment is done in p1_one/models.py).
Numbers are drawn i.i.d. from a Normal(mean = 55, variance = 400) distribution in the
high-volatility condition and Normal(mean = 55, variance = 20) in the low-volatility
condition, rounded to the nearest integer, truncated to [11, 99], and re-drawn whenever
they equal the benchmark 55 (the task is to judge whether a number is higher or lower
than 55, so 55 is never shown).

The exact sequences used during data collection are stored in numbers_high.csv and
numbers_low.csv. This script documents how they were produced. Re-running it draws a NEW
random sample and writes it to numbers_high_new.csv / numbers_low_new.csv; it does NOT
overwrite the sequences that were actually shown to participants.

Requires numpy. Run from the project root:  python generate_numbers.py
"""

import os
import numpy as np

SUBJECTS = 200
TRIALS = 150
MEAN = 55
SD_HIGH = np.sqrt(400)   # high-volatility condition (variance 400)
SD_LOW = np.sqrt(20)     # low-volatility condition (variance 20)
LOWER, UPPER = 11, 99
BENCHMARK = 55           # never shown (excluded from the draws)

here = os.path.dirname(os.path.abspath(__file__))


def draw_matrix(sd):
    matrix = []
    for s in range(SUBJECTS):
        trials = []
        while len(trials) < TRIALS:
            x = int(np.round(np.random.normal(loc=MEAN, scale=sd)))
            if x != BENCHMARK and LOWER <= x <= UPPER:
                trials.append(x)
        matrix.append(trials)
    return np.array(matrix, dtype=int)


np.savetxt(os.path.join(here, 'numbers_high_new.csv'), draw_matrix(SD_HIGH), fmt='%i', delimiter=',')
np.savetxt(os.path.join(here, 'numbers_low_new.csv'), draw_matrix(SD_LOW), fmt='%i', delimiter=',')

print('Wrote fresh draws to numbers_high_new.csv and numbers_low_new.csv')
print('The sequences actually used in the experiment remain in numbers_high.csv / numbers_low.csv.')
