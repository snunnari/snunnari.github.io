from otree.api import Currency as c, currency_range
from . import pages
from ._builtin import Bot
from .models import Constants
import random


class PlayerBot(Bot):
    """Automated playthrough used by `otree test one_v2` to check p1_one runs.

    Reads the instructions, answers the comprehension quiz correctly, clicks through
    the practice screens, and then plays each of the 150 discrimination rounds with a
    random response. Used only for automated testing; plays no role in data collection.
    """

    def play_round(self):
        if self.round_number == 1:
            yield pages.Welcome
            # Mobile is shown only to mobile browsers; the test client is not mobile.
            yield pages.Instructions
            yield pages.QuizQuestions, dict(quiz_answer_1='55')  # correct answer
            yield pages.QuizAnswers
            yield pages.Practice_Cross_1
            yield pages.Practice_1
            yield pages.Practice_Cross_2
            yield pages.Practice_2
            yield pages.Practice_End
        yield pages.Cross
        yield pages.Decision, dict(higher=random.choice([True, False]), dectime=1.0)
