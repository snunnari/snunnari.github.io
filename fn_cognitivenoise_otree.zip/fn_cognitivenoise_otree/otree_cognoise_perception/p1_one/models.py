from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

import random
from statistics import mean
import math
import csv

with open('numbers_high.csv', newline='') as numbers_high:
    data_high = csv.reader(numbers_high, delimiter=',', quotechar='|')
    data_vector_high = []
    for row in data_high:
        data_vector_high.append(row)

with open('numbers_low.csv', newline='') as numbers_low:
    data_low = csv.reader(numbers_low, delimiter=',', quotechar='|')
    data_vector_low = []
    for row in data_low:
        data_vector_low.append(row)

author = 'Cary Frydman and Salvatore Nunnari'

doc = """
Part 1 of the Online Appendix experiment: a perceptual discrimination task. On each of
150 rounds the participant judges whether a displayed number is higher or lower than the
benchmark (55). Numbers are drawn from a high- or low-volatility sequence (between
subjects). Runs before p2_one (belief elicitation) in the app sequence.
"""


class Constants(BaseConstants):
    name_in_url = 'p1_one'
    players_per_group = None
    num_rounds = 150

    #low = 31
    #high = 99
    threshold = 55

    rate_accuracy = 1.5
    rate_speed = 1.0

    #breaks = [math.ceil(num_rounds/2) + 1]  # pause at half task; if empty, app will not pause
    breaks = [i for i in range(51, num_rounds, 50)] # pause every 50 trials

class Subsession(BaseSubsession):

    def creating_session(self):

        # AMOUNTS FROM CSV #
        # N: to generate a new set of numbers, run script "generate_numbers.py" in project folder
        for p in self.get_players():
            if self.round_number == 1 and p.id_in_group % 2 == 1:
                p.participant.vars['numbers'] = data_vector_high[int((p.id_in_group+1)/2-1)]
            elif self.round_number == 1 and p.id_in_group % 2 == 0:
                p.participant.vars['numbers'] = data_vector_low[int(p.id_in_group/2-1)]

            p.number = int(p.participant.vars['numbers'][self.round_number - 1])

            p.participant.vars['correct_list'] = []
            p.participant.vars['dectime_list'] = []
            p.participant.vars['close_correct_list'] = []
            p.participant.vars['far_correct_list'] = []

        # AMOUNTS RANDOMLY GENERATED AND ASSIGNED AT ROUND 1 FOR ALL ROUNDS
        # for p in self.get_players():
        #     if self.round_number == 1:
        #         numbers = []
        #         for round in range(Constants.num_rounds):
        #             number = random.randint(Constants.low, Constants.high)
        #             while number == Constants.threshold:
        #                 number = random.randint(Constants.low, Constants.high)
        #             numbers.append(number)
        #
        #         p.participant.vars['numbers'] = numbers
        #         p.participant.vars['correct_list'] = []
        #         p.participant.vars['dectime_list'] = []
        #         p.participant.vars['close_correct_list'] = []
        #         p.participant.vars['far_correct_list'] = []
        #
        #     p.number = int(p.participant.vars['numbers'][self.round_number - 1])

        # [OLD] AMOUNTS RANDOMLY GENERATED AND ASSIGNED AT EACH ROUND
        # if self.round_number == 1:
        #     for p in self.get_players():
        #
        #         numbers = []
        #
        #         for round in range(Constants.num_rounds):
        #             number = random.randint(Constants.low, Constants.high)
        #
        #             while number == Constants.threshold:
        #                 number = random.randint(Constants.low, Constants.high)
        #
        #             numbers.append(number)
        #
        #         p.participant.vars['numbers'] = numbers
        #         p.participant.vars['correct_list'] = []
        #         p.participant.vars['dectime_list'] = []
        #         p.participant.vars['close_correct_list'] = []
        #         p.participant.vars['far_correct_list'] = []


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    quiz_answer_1 = models.StringField(
            choices=[['56', '56'], ['65', '65'], ['55', '55'], ['89', '89']],
            widget=widgets.RadioSelect,
            label=''''''
            )

    #quiz_answer_2 = models.StringField(
    #        choices=[['A', 'A'], ['Z', 'Z'], ['L', 'L'], ['?', '?']],
    #        widget=widgets.RadioSelect,
    #        label=''''''
    #        )

    #quiz_answer_3 = models.StringField(
    #        choices=[['A', 'A'], ['Z', 'Z'], ['L', 'L'], ['?', '?']],
    #        widget=widgets.RadioSelect,
    #        label=''''''
    #        )

    number = models.IntegerField()
    higher = models.BooleanField()
    correct = models.BooleanField()
    dectime = models.FloatField(blank=True)

    def evaluate_choice(self):
        # numbers = self.participant.vars['numbers']
        # self.number = numbers[self.round_number - 1]

        if self.higher and self.number > Constants.threshold:
            self.correct = True
        elif not self.higher and self.number < Constants.threshold:
            self.correct = True
        else:
            self.correct = False

    def update_accuracy_speed(self):
        self.participant.vars['correct_list'].append(self.correct)
        self.participant.vars['dectime_list'].append(self.dectime)

        close_interval = [i for i in range(52, 59)]
        if self.number in close_interval:
            self.participant.vars['close_correct_list'].append(self.correct)
        else:
            self.participant.vars['far_correct_list'].append(self.correct)
