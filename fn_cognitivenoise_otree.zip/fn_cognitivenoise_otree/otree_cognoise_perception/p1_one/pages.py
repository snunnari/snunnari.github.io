from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
#from user_agents import parse


class Welcome(Page):

    def is_displayed(self):
        return self.round_number == 1

    def before_next_page(self):
        # .get(...) rather than [...] so a request without a User-Agent header (e.g. the
        # test client used by `otree test`) does not crash; real browsers always send one,
        # so behavior during data collection is unchanged.
        user_agent = self.request.META.get('HTTP_USER_AGENT', '')
        is_mobile = False
        for substring in ['Mobi', 'Android']:
            if substring in user_agent:
                is_mobile = True
        self.participant.vars['is_mobile'] = is_mobile

        #user_agent = parse(user_agent)
        #is_safari = False
        # print(user_agent)

        #for substring in ['Safari']:
        #    if substring in str(user_agent):
        #        is_safari = True
        #        print('Participant is using Safari!')
        #    else:
        #        print('Participant is not using Safari')
        #self.participant.vars['is_safari'] = is_safari


class Mobile(Page):

    def is_displayed(self):
        return self.participant.vars['is_mobile']

class Instructions(Page):

    def is_displayed(self):
        return self.round_number == 1

class QuizQuestions(Page):

    form_model = 'player'
    form_fields = ['quiz_answer_1']
    #form_fields = ['quiz_answer_1', 'quiz_answer_2', 'quiz_answer_3']

    def is_displayed(self):
        return self.round_number == 1

class QuizAnswersWrong(Page):

    def is_displayed(self):
        return self.round_number == 1 and self.player.quiz_answer_1 != "55"
        #return self.round_number == 1 and (self.player.quiz_answer_1 != "55" or self.player.quiz_answer_2 != "A" or self.player.quiz_answer_3 != "L")

class QuizAnswers(Page):

    def is_displayed(self):
        return self.round_number == 1

class Practice_Cross_1(Page):
    def is_displayed(self):
        return self.round_number == 1

class Practice_1(Page):
    def is_displayed(self):
        return self.round_number == 1

class Practice_Cross_2(Page):
    def is_displayed(self):
        return self.round_number == 1

class Practice_2(Page):
    def is_displayed(self):
        return self.round_number == 1

class Practice_End(Page):
    def is_displayed(self):
        return self.round_number == 1


class Cross(Page):

    def vars_for_template(self):
        return dict(
            turn=self.round_number
        )

class Decision(Page):
    form_model = 'player'
    form_fields = ['higher', 'dectime']

    def vars_for_template(self):
        return dict(
            number=self.participant.vars['numbers'][self.round_number - 1],
            turn=self.round_number
        )

    def before_next_page(self):
        return self.player.evaluate_choice(), self.player.update_accuracy_speed()


page_sequence = [Welcome, Mobile, Instructions, QuizQuestions, QuizAnswersWrong, QuizAnswers, Practice_Cross_1, Practice_1, Practice_Cross_2, Practice_2, Practice_End, Cross, Decision]
