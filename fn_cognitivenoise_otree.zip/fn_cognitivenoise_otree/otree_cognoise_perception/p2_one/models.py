from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

import random
from statistics import mean
import numpy as np
import csv
import math

with open('past_data/PastDataPer.csv', newline='') as csvfile:
    data = csv.reader(csvfile, delimiter=',', quotechar='|')
    data_vector = []
    for row in data:
        data_vector.append(row)

data = data_vector[1:]

author = 'Cary Frydman and Salvatore Nunnari'

doc = """
Part 2 of the Online Appendix experiment: belief elicitation. Participants forecast
their own discrimination accuracy (on numbers close to vs. far from the benchmark) and
the accuracy of other participants. Runs after p1_one in the app sequence.
"""

class Constants(BaseConstants):
    name_in_url = 'p2_one'
    players_per_group = None
    num_rounds = 1

    threshold = 55
    rate_accuracy = 1.5
    rate_speed = 1.0
    forecast_tolerance = 1
    forecast_prize = 0.50

class Subsession(BaseSubsession):

    def creating_session(self):
        rounds = Constants.num_rounds

        if self.round_number == 1:
            for p in self.get_players():

                p.own_first = np.random.randint(0,2,1)
                p.own_order = np.random.randint(1,2,1)
                p.other_order = np.random.randint(1,2,1)
                p.participant.vars['own_first'] = p.own_first
                p.participant.vars['own_order'] = p.own_order
                p.participant.vars['other_order'] = p.other_order

            # Create Matrix of past scores
            #past_scores = data.copy()
            #self.session.vars['past_scores'] = past_scores

class Group(BaseGroup):
    pass

class Player(BasePlayer):

    attention = models.StringField(
        label='',
        blank=False
    )

    own_first = models.IntegerField()
    own_order = models.IntegerField()
    other_order = models.IntegerField()

    forecast_own_close = models.FloatField(label='', min=0, max=100)
    forecast_own_far = models.FloatField(label='', min=0, max=100)
    forecast_other_47 = models.FloatField(label='', min=0, max=100)
    forecast_other_54 = models.FloatField(label='', min=0, max=100)

    accuracy_own_close = models.FloatField()
    accuracy_own_far = models.FloatField()
    #accuracy_other_close = models.FloatField()
    #accuracy_other_far = models.FloatField()

    forecast_own_close_payoff = models.CurrencyField()
    forecast_own_far_payoff = models.CurrencyField()
    #forecast_other_close_payoff = models.CurrencyField()
    #forecast_other_far_payoff = models.CurrencyField()

    #feedback = models.LongStringField(label='', blank=True)

    #pay_forecast_own = models.CurrencyField()
    #pay_forecast_other = models.CurrencyField()
    pay_task = models.CurrencyField()

    def evaluate_forecast_own(self):
        self.forecast_own_close_payoff = c(0)
        self.forecast_own_far_payoff = c(0)

        t = Constants.forecast_tolerance

        avg_close_correct_list = mean(self.participant.vars['close_correct_list'])
        avg_far_correct_list = mean(self.participant.vars['far_correct_list'])

        self.accuracy_own_close = round(avg_close_correct_list * 100, 2)
        self.accuracy_own_far = round(avg_far_correct_list * 100, 2)

        if self.accuracy_own_close - t <= self.forecast_own_close <= self.accuracy_own_close + t:
            self.forecast_own_close_payoff = c(Constants.forecast_prize)

        if self.accuracy_own_far - t <= self.forecast_own_far <= self.accuracy_own_far + t:
            self.forecast_own_far_payoff = c(Constants.forecast_prize)

    #def evaluate_forecast_other(self):
    #    self.forecast_other_close_payoff = c(0)
    #    self.forecast_other_far_payoff = c(0)

    #    past_scores = self.session.vars['past_scores']
    #    chosen_row = random.randrange(0, len(past_scores))

    #    t = Constants.forecast_tolerance

    #    self.accuracy_other_close = float(past_scores[chosen_row][2])
    #    self.accuracy_other_far = float(past_scores[chosen_row][3])

    #    if self.accuracy_other_close - t <= self.forecast_other_close <= self.accuracy_other_close + t:
    #        self.forecast_other_close_payoff = c(Constants.forecast_prize)

    #    if self.accuracy_other_far - t <= self.forecast_other_far <= self.accuracy_other_far + t:
    #        self.forecast_other_far_payoff = c(Constants.forecast_prize)

    def set_payoff(self):
        rate_accuracy = Constants.rate_accuracy
        rate_speed = Constants.rate_speed

        # pay from discrimination task
        self.pay_task = c(rate_accuracy * mean(self.participant.vars['correct_list']) - rate_speed * round(mean(self.participant.vars['dectime_list']), 2))

        # pay from own forecast
        #self.pay_forecast_own = c(self.forecast_own_close_payoff \
        #                          + self.forecast_own_far_payoff)

        # pay from other forecast
        #self.pay_forecast_other = c(self.forecast_other_close_payoff \
        #                          + self.forecast_other_far_payoff)

        # payoff computation
        #if self.round_number == Constants.num_rounds:
        #    self.payoff = self.pay_task + self.pay_forecast_own + self.pay_forecast_other
