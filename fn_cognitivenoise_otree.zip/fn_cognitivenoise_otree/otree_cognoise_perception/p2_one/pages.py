from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
from statistics import mean


class AttentionCheck(Page):

    form_model = 'player'
    form_fields = ['attention']

    def is_displayed(self):
        return self.round_number == Constants.num_rounds

class Forecast1(Page):
    form_model = 'player'

    def get_form_fields(self):
        if self.participant.vars['own_first'] == 1:
            return ['forecast_own_close', 'forecast_own_far']
        else:
            return ['forecast_other_47', 'forecast_other_54']

    def is_displayed(self):
        return self.round_number == Constants.num_rounds

    def before_next_page(self):
        if self.participant.vars['own_first']:
            return self.player.evaluate_forecast_own()
        #else:
        #    return self.player.evaluate_forecast_other()

    def vars_for_template(self):
        return dict(
            OwnFirst=self.participant.vars['own_first'],
            OwnOrder=self.participant.vars['own_order'],
            OtherOrder=self.participant.vars['other_order']
        )


class Forecast2(Page):
    form_model = 'player'

    def get_form_fields(self):
        if self.participant.vars['own_first'] == 0:
            return ['forecast_own_close', 'forecast_own_far']
        else:
            return ['forecast_other_47', 'forecast_other_54']

    def is_displayed(self):
        return self.round_number == Constants.num_rounds

    def before_next_page(self):
        if not self.participant.vars['own_first']:
            return self.player.evaluate_forecast_own()
        #else:
        #    return self.player.evaluate_forecast_other()

    def vars_for_template(self):
        return dict(
            OwnFirst=self.participant.vars['own_first'],
            OwnOrder=self.participant.vars['own_order'],
            OtherOrder=self.participant.vars['other_order']
        )

class Feedback(Page):
    def is_displayed(self):
        return self.round_number == Constants.num_rounds
    form_model = 'player'
    form_fields = ['feedback']

    def before_next_page(self):
        return self.player.set_payoff()


class PreResults(Page):

    def before_next_page(self):
        return self.player.set_payoff()

    def is_displayed(self):
        return self.round_number == Constants.num_rounds


class Results(Page):

    def is_displayed(self):
        return self.round_number == Constants.num_rounds

    def vars_for_template(self):
        return dict(
            accuracy=mean(self.participant.vars['correct_list']) * 100,
            accuracy_per=mean(self.participant.vars['correct_list']),
            speed=round(mean(self.participant.vars['dectime_list']), 2),
            OwnForecastFirst=self.participant.vars['own_first'],
            OwnOrder=self.participant.vars['own_order'],
            OtherOrder=self.participant.vars['other_order']
        )

class Mobile(Page):

    def is_displayed(self):
        return self.participant.vars['is_mobile']


page_sequence = [
                 #AttentionCheck,
                 Forecast1,
                 Forecast2,
                 #Feedback,
                 PreResults,
                 Results
                 ]
