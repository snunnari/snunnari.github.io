from otree.api import Currency as c, currency_range
from . import pages
from ._builtin import Bot
from .models import Constants


class PlayerBot(Bot):
    """Automated playthrough used by `otree test one_v2` to check p2_one runs.

    Submits the two belief-elicitation screens (in the random order set by `own_first`)
    and advances through the results pages. Used only for automated testing.
    """

    def play_round(self):
        own_first = self.participant.vars['own_first']
        # own_first is stored as a length-1 numpy array; coerce to a plain int.
        try:
            own_first = int(own_first)
        except (TypeError, ValueError):
            own_first = int(own_first[0])

        own_fields = dict(forecast_own_close=80, forecast_own_far=95)
        other_fields = dict(forecast_other_47=70, forecast_other_54=60)

        if own_first == 1:
            yield pages.Forecast1, own_fields
            yield pages.Forecast2, other_fields
        else:
            yield pages.Forecast1, other_fields
            yield pages.Forecast2, own_fields
        yield pages.PreResults
        yield pages.Results
