# Online Appendix Experiment (Discrimination Task + Beliefs) — oTree software

This folder contains the [oTree](https://www.otree.org) software used to run the
**additional experiment reported in the Online Appendix** of:

> Cary Frydman and Salvatore Nunnari, "Coordination with Cognitive Noise."

This project runs the experiment as a sequence of **two apps**, `p1_one`
(a perceptual discrimination task) followed by `p2_one` (belief elicitation), wired
together in the single session configuration **`one_v2`**.

## What the experiment does

**Part 1 — Discrimination task (`p1_one`, 150 rounds).** On each round a single number is
displayed and the participant judges whether it is **higher or lower than the benchmark
55** (by pressing the "A" key for lower / "D" key for higher; left/right labels are
"Lower (A)" and "Higher (D)"). A response is *correct* if the participant says "higher"
and the number exceeds 55, or "lower" and the number is below 55. The number 55 itself is
never shown. The task is incentivized for both accuracy and speed.

Participants are split between two **volatility conditions** (between subjects, by
participant id parity): odd participants see numbers drawn from a high-volatility
sequence, *N*(55, 400); even participants see a low-volatility sequence, *N*(55, 20).
Numbers are pre-generated and stored in `numbers_high.csv` / `numbers_low.csv`. The app
separately tracks accuracy on numbers **close** to the benchmark (52–58) versus **far**
from it. The task begins with instructions, a one-question comprehension quiz, and a short
set of practice trials, and pauses for a rest break every 50 rounds.

**Part 2 — Belief elicitation (`p2_one`, 1 round).** Participants make two kinds of
forecasts (the order of the two screens is randomized per participant):

- **Own accuracy:** forecast their own percentage of correct answers on numbers *close*
  to the benchmark and on numbers *far* from it (`forecast_own_close`, `forecast_own_far`).
  These forecasts are scored against the participant's actual Part-1 performance: a forecast
  within ±1 percentage point of the realized accuracy earns a fixed prize.
- **Others' accuracy:** forecast the accuracy of other participants at specific numbers,
  one far from the benchmark (47) and one close to it (54) — `forecast_other_47`,
  `forecast_other_54`.

`p2_one` loads `past_data/PastDataPer.csv` (aggregate close/far accuracy of
earlier participants) at startup; this file is required for the app to run.

### Flow of the two apps

```
p1_one:  Welcome -> [Mobile] -> Instructions -> QuizQuestions -> [QuizAnswersWrong]
         -> QuizAnswers -> Practice screens -> [ Cross -> Decision ] x 150
p2_one:  Forecast1 -> Forecast2 -> PreResults -> Results
```

`Mobile` is shown only to participants on a phone (the study requires a physical
keyboard); `QuizAnswersWrong` is shown only if the quiz is failed.


## A note on server load and recruitment

The discrimination task presents many short pages in quick succession (two page loads per
round over 150 rounds), and participants advance through them very fast. If too many
participants are active at the same time, this volume of rapid requests could overload
the server. For the data collection reported in the paper, we addressed this by
**recruiting participants in small batches** rather than all at once.

## Requirements

- **Python 3.8** (the study ran under 3.8.10)
- **oTree 3.3.11** (the legacy, class-based oTree API — this app is not compatible with oTree 5+)
- **numpy** (used by `p2_one` at runtime and by `generate_numbers.py`)

`requirements.txt` also lists `psycopg2` (PostgreSQL) and `sentry-sdk` (error monitoring),
which were used for the original cloud deployment and are **not** needed to run the
experiment locally with the default SQLite database.

### Creating the environment

With conda (recommended):

```bash
conda create -n cognoise-otree3 python=3.8
conda activate cognoise-otree3
pip install otree==3.3.11 numpy
```

Or with a plain virtual environment:

```bash
python3.8 -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install otree==3.3.11 numpy
```


## Running the experiment

These steps deploy the apps on your **local machine**, which is all you need to inspect or
reproduce the experiment. For the actual data collection they were hosted on an **online
server** (in our case, Heroku); the `Procfile` and `runtime.txt` files are that cloud
configuration.

From this folder, with the environment activated:

```bash
otree devserver
```

Then open <http://localhost:8000> and start the **`one_v2`** session (via Demo, via
Sessions, or via one of the predefined Rooms in `settings.py`).

To verify that the apps install and run correctly, run the automated playthrough:

```bash
otree test one_v2
```

This sends bots through the whole sequence — instructions, quiz, practice, all 150
discrimination rounds, and the belief screens — and should finish with
`Bots completed session`. The bots are used only for testing.

> If `otree devserver` reports a database error on first run, delete `db.sqlite3` (if
> present) and start it again; do not run `otree resetdb` immediately before `devserver`.


## Project structure

```
p1_one/                 discrimination task (Part 1); reads numbers_high/low.csv
p2_one/                 belief elicitation (Part 2); reads past_data/PastDataPer.csv
numbers_high.csv        150 numbers x 200 participant slots, high-volatility sequences
numbers_low.csv         150 numbers x 200 participant slots, low-volatility sequences
generate_numbers.py     documents how numbers_high/low.csv were drawn
past_data/PastDataPer.csv   aggregate close/far accuracy of earlier participants,
                            loaded by p2_one (benchmark used in the belief task)
settings.py             single session config (one_v2), rooms, currency, admin
manage.py               oTree/Django entry point
requirements.txt        packages used for the original deployment
runtime.txt, Procfile   configuration for cloud (Heroku) deployment
_static/, _templates/   project-wide static assets and the base page template
```

### Key parameters

| Where | Constant | Value | Meaning |
|-------|----------|-------|---------|
| `p1_one` | `num_rounds` | 150 | discrimination rounds |
| `p1_one` | `threshold` | 55 | the benchmark; numbers equal to 55 are never shown |
| `p1_one` | `rate_accuracy`, `rate_speed` | 1.5, 1.0 | accuracy reward and speed penalty rates |
| `p1_one` | `breaks` | 51, 101, 151 | rounds at which a rest break is shown |
| `p2_one` | `forecast_tolerance` | 1 | ± percentage points within which an own-accuracy forecast wins |
| `p2_one` | `forecast_prize` | 0.50 | prize for a correct forecast |