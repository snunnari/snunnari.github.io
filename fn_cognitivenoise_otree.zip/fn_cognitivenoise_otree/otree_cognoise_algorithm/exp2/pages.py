from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
#from user_agents import parse
from statistics import mean

class Welcome(Page):

    def is_displayed(self):
        return self.round_number == 1

    #def before_next_page(self):
    #    user_agent = self.request.META['HTTP_USER_AGENT']
    #    is_mobile = False
    #    for substring in ['Mobi', 'Android']:
    #        if substring in user_agent:
    #            is_mobile = True
    #    self.participant.vars['is_mobile'] = is_mobile

class Instructions_1(Page):

    def is_displayed(self):
        return self.round_number == 1

class Instructions_2(Page):

    def is_displayed(self):
        return self.round_number == 1

class QuizQuestions(Page):

    form_model = 'player'
    form_fields = ['quiz_answer_1', 'quiz_answer_2', 'quiz_answer_3']

    def is_displayed(self):
        return self.round_number == 1

class QuizAnswersWrong(Page):

    def is_displayed(self):
        return self.round_number == 1 and (self.player.quiz_answer_1 != "1" or self.player.quiz_answer_2 != "3" or self.player.quiz_answer_3 != "2")

class QuizAnswersRight(Page):

    def is_displayed(self):
        return self.round_number == 1

class Decision(Page):

    #timeout_seconds = 300

    form_model = 'player'
    form_fields = ['decision', 'dectime']

    #def before_next_page(self):
    #    if self.timeout_happened:
    #        self.player.decision = "TimeOut"

class Cross(Page):

    def vars_for_template(self):
        return dict(
            #break_num = 1,
            break_num=int((self.round_number - 1) / 45),
            num_parts=len(Constants.breaks) + 1
        )

#class Feedback(Page):
#    def is_displayed(self):
#        return self.round_number == Constants.num_rounds
#    form_model = 'player'
#    form_fields = ['feedback']

class Results(Page):

    def is_displayed(self):
        return self.round_number == Constants.num_rounds

    def vars_for_template(self):
        paid_round = self.participant.vars['paid_round']
        paid = self.player.in_round(paid_round)
        return dict(
            paid_round = paid_round,
            number_on_left = paid.number_on_left,
            number = paid.number,
            decision = paid.decision
        )

#class Mobile(Page):
#    def is_displayed(self):
#        return self.participant.vars['is_mobile']

#page_sequence = [Welcome, Mobile, Instructions, QuizQuestions, QuizAnswersWrong,
#                 QuizAnswersRight, Cross, Decision, Results]
#page_sequence = [Welcome, Instructions, QuizQuestions, QuizAnswersWrong,
#                 QuizAnswersRight, Cross, Decision, Results]
#page_sequence = [Welcome, Cross, Decision, Results]
page_sequence = [Welcome, Instructions_1, Instructions_2, QuizQuestions, QuizAnswersWrong,
                 QuizAnswersRight, Cross, Decision, Results]
