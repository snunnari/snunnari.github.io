from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

from . import payoffs_high
import random
import math


author = 'Cary Frydman and Salvatore Nunnari'

doc = """
Experiment 2 (Human vs Algorithm) in Frydman and Nunnari, "Coordination with
Cognitive Noise." Subjects play 300 one-shot 2x2 coordination games against a
computerized opponent that follows a known, deterministic threshold rule.
"""

class Constants(BaseConstants):
    name_in_url = 'exp2'
    players_per_group = None
    num_rounds = 300

    upside = 63 # earnings if B and opponent chooses B
    downside = 47 # earnings if B and opponent chooses A

    #breaks = [] # no pause
    #breaks = [math.ceil(num_rounds / 2) + 1]  # pause after 50% of total trials
    breaks = [i for i in range(51, num_rounds, 50)] # pause every 50 trials
    #breaks = [i for i in range(46, num_rounds, 45)] # pause every 45 trials


class Subsession(BaseSubsession):

    def creating_session(self):
        # The integer values of theta (the points delivered by Option A) shown to each
        # participant on each of the 300 rounds are pre-generated and stored in
        # payoffs_high.py as `matrix_high` (one 300-round sequence per participant id).
        # All participants are assigned to the high-volatility condition used in
        # Experiment 2: theta ~ Normal(55, 400), rounded to the nearest integer and
        # truncated to [11, 99]. See generate_payoffs.py for how the sequences were drawn.

        if self.round_number == 1:
            amounts_high = payoffs_high.matrix_high
            for p in self.get_players():
                p.participant.vars['random_amounts'] = amounts_high[p.id_in_group]
                # one round, drawn uniformly at random for each participant,
                # determines the bonus payment (revealed on the Results page)
                p.participant.vars['paid_round'] = random.randint(1, Constants.num_rounds)

        for p in self.get_players():
            p.number_on_left = random.choice([True, False])
            p.number = int(p.participant.vars['random_amounts'][self.round_number - 1])


class Group(BaseGroup):
    pass

class Player(BasePlayer):
    quiz_answer_1 = models.StringField(
            choices=[['1', 'Option A'],
            ['2', 'Option B'],
            ['3', 'I do not have enough information']],
            widget=widgets.RadioSelect,
            label=''''''
    )

    quiz_answer_2 = models.StringField(
            choices=[['1','I earn 58 points' ],
            ['2', 'I earn 47 points'],
            ['3', 'I earn 63 points'],
            ['4', 'I do not have enough information']],
            widget=widgets.RadioSelect,
            label=''''''
    )

    quiz_answer_3 = models.StringField(
            choices=[['1','I earn 51 points' ],
            ['2', 'I earn 47 points'],
            ['3', 'I earn 63 points'],
            ['4', 'I do not have enough information']],
                widget=widgets.RadioSelect,
                label=''''''
        )

    number = models.IntegerField()
    number_on_left = models.BooleanField()
    decision = models.StringField()
    dectime = models.FloatField(blank=True)
