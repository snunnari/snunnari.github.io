from otree.api import Currency as c, currency_range, Submission
from . import pages
from ._builtin import Bot
from .models import Constants
import random


class PlayerBot(Bot):
    """Automated playthrough used by `otree test exp2` to check the app runs.

    The bot reads the instructions, answers the comprehension quiz correctly, and
    then plays each of the 300 rounds by choosing a random option. It is only used
    for automated testing; it plays no role in actual data collection.
    """

    def play_round(self):
        if self.round_number == 1:
            yield pages.Welcome
            yield pages.Instructions_1
            yield pages.Instructions_2
            # Correct answers to the three comprehension questions.
            yield pages.QuizQuestions, dict(
                quiz_answer_1='1', quiz_answer_2='3', quiz_answer_3='2'
            )
            # QuizAnswersWrong is not displayed because the answers are correct.
            yield pages.QuizAnswersRight
        yield pages.Cross
        yield pages.Decision, dict(decision=random.choice(['Left', 'Right']), dectime=1.23)
        if self.round_number == Constants.num_rounds:
            # Results is the terminal page (it shows the completion link, no button).
            yield Submission(pages.Results, check_html=False)

    def validate_play(self):
        # The value of theta assigned this round must lie in the support [11, 99].
        assert self.player.number is not None
        assert 11 <= self.player.number <= 99
