"""
Generate the random sequences of theta shown to participants in Experiment 2
(Human vs Algorithm) of Frydman and Nunnari, "Coordination with Cognitive Noise."

In every round, Option A delivers a sure number of points, theta, which is the only
feature of the game that varies across rounds. Each of the 300 potential participants
is assigned an independent sequence of 300 integer values of theta, drawn i.i.d. from
a Normal(mean = 55, variance = 400) distribution (the high-volatility condition used
in Experiment 2), rounded to the nearest integer and truncated to [11, 99] (values
that fall outside the range are re-drawn). The low-volatility condition used in
Experiment 1 (the human-vs-human coordination game) instead drew theta from a
Normal(mean = 55, variance = 20) distribution.

The exact sequences used during data collection are stored in exp2/payoffs_high.py as
the variable `matrix_high`, a list of 300 lists of 300 strings. This script documents
how those sequences were originally produced. Re-running it draws a NEW random sample
and writes it to exp2/payoffs_high_new.py; it does NOT overwrite the sequences that
were actually shown to participants. To use a freshly drawn sample, inspect the output
file and copy its `matrix_high` into exp2/payoffs_high.py.

Requires numpy (see requirements.txt). Run from the project root:  python generate_payoffs.py
"""

import os
import numpy as np

SUBJECTS = 300        # number of independent payoff sequences
ROUNDS = 300          # rounds per participant
MEAN = 55             # mean of theta
VARIANCE = 400        # high-volatility condition (Experiment 2); low volatility used 20
SD = np.sqrt(VARIANCE)
LOWER, UPPER = 11, 99  # theta is re-drawn until it falls in this inclusive range

here = os.path.dirname(os.path.abspath(__file__))
out_path = os.path.join(here, 'exp2', 'payoffs_high_new.py')

matrix_high = []
for s in range(SUBJECTS):
    trials = []
    while len(trials) < ROUNDS:
        theta = int(np.round(np.random.normal(loc=MEAN, scale=SD)))
        if LOWER <= theta <= UPPER:
            trials.append(theta)
    matrix_high.append(trials)

# Write in the same module format as exp2/payoffs_high.py (values stored as strings).
formatted = [[str(theta) for theta in row] for row in matrix_high]
with open(out_path, 'w') as f:
    f.write('matrix_high = ' + repr(formatted) + '\n')

print('Wrote a fresh draw of {} x {} theta values to {}'.format(SUBJECTS, ROUNDS, out_path))
print('The sequences actually used in the experiment remain in exp2/payoffs_high.py.')
