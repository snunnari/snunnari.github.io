# Experiment 2 (Human vs Algorithm) — oTree software

This folder contains the [oTree](https://www.otree.org) software used to run **Experiment 2
(Human vs Algorithm)** in:

> Cary Frydman and Salvatore Nunnari, "Coordination with Cognitive Noise."

This project contains a single oTree app, `exp2`, which implements Experiment 2.

## What the experiment does

On each of 300 rounds, a subject plays the one-shot 2×2 coordination game of the paper against
a **computerized opponent** whose strategy is known and deterministic. The two actions are
labeled neutrally as **Option A** and **Option B** (their left/right screen position is
randomized each round):

- **Option A** ("Not Invest") pays a sure number of points, *θ*, displayed on screen.
- **Option B** ("Invest") pays **47** points if the opponent chooses A and **63** points if the
  opponent chooses B (these are the parameters *a* = 47 and *b* = 63 of the paper).

The subject is told that the computerized opponent follows the rule:

- if Option A delivers **55 points or more**, the opponent chooses **Option A**;
- if Option A delivers **less than 55**, the opponent chooses **Option B**.

Equivalently, the computer **invests (Option B) if and only if θ < 55**. The best response for
a subject who perceives θ without noise is therefore to invest iff θ < 55. Because the opponent
is a computer playing a known rule, this design shuts down strategic uncertainty and isolates
the role of cognitive noise (see Section 5 of the paper).

Each subject sees an independent sequence of 300 values of θ drawn from the **high-volatility**
distribution used in the paper, *θ* ~ Normal(55, 400), rounded to the nearest integer and
truncated to [11, 99]. Subjects first read instructions and must answer a three-question
comprehension quiz correctly to proceed; they receive no feedback between rounds. At the end,
one round determines the bonus payment.

### Flow of the app (page sequence)

`Welcome → Instructions_1 → Instructions_2 → QuizQuestions → (QuizAnswersWrong) →
QuizAnswersRight → [ Cross → Decision ] × 300 → Results`

The instruction, quiz, and result pages are shown only on the first/last round. `Cross` is a
fixation screen shown before each decision and also serves as the rest break between the six
blocks of 50 rounds. `QuizAnswersWrong` is shown only if a quiz answer is incorrect, in which
case the participant cannot continue.


## Requirements

- **Python 3.8** (the study ran under 3.8.10)
- **oTree 3.3.11** (the legacy, class-based oTree API — this app is not compatible with oTree 5+)
- **numpy** (only needed if you want to re-run `generate_payoffs.py`)

`requirements.txt` lists the full set of packages used for the original cloud deployment,
including `psycopg2` (PostgreSQL) and `sentry-sdk` (error monitoring). Those two are **not**
needed to run the experiment locally with the default SQLite database.

### Creating the environment

With conda (recommended):

```bash
conda create -n cognoise-otree3 python=3.8
conda activate cognoise-otree3
pip install otree==3.3.11 numpy
```

Or with a plain virtual environment:

```bash
python3.8 -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install otree==3.3.11 numpy
```


## Running the experiment

These steps deploy the app on your **local machine**. For the actual data collection the app was hosted on an **online
server** (in our case, Heroku); the `Procfile` and `runtime.txt` files are that cloud
configuration.

From this folder, with the environment activated:

```bash
otree devserver
```

Then open <http://localhost:8000> and either:

- open the **Demo** section and start the `exp2` session, or
- create a session under **Sessions**, or
- use one of the predefined **Rooms** (the original study ran on Prolific).

To verify that the app installs and runs correctly, run the automated playthrough:

```bash
otree test exp2
```

This sends one or more bots through the entire experiment (instructions, quiz, and all 300
rounds) and should complete with `Bots completed session`. The bot is used only for testing and
plays no role in data collection.

> If `otree devserver` reports a database error on first run, delete the `db.sqlite3` file (if
> present) and start it again. Do not run `otree resetdb` immediately before `otree devserver`;
> `devserver` initializes the database itself.


## Project structure

```
exp2/                       the oTree app implementing Experiment 2
  models.py                 Constants, Subsession, Group, Player; assigns each
                            participant a 300-round sequence of theta
  pages.py                  page logic and the page sequence
  payoffs_high.py           matrix_high: the 300 x 300 integer values of theta actually
                            shown to participants (one sequence per participant id)
  templates/exp2/           one HTML template per page
  tests.py                  bot used by `otree test exp2`
  _builtin/                 oTree-generated helper (do not edit)
generate_payoffs.py         documents how the theta sequences in payoffs_high.py were drawn
settings.py                 session config (exp2), rooms, currency, admin
manage.py                   oTree/Django entry point
requirements.txt            packages used for the original deployment
runtime.txt, Procfile       configuration for cloud (Heroku) deployment
_static/, _templates/       project-wide static assets and the base page template
LICENSE                     license (MIT, from the oTree project template)
```

### Key parameters (in `exp2/models.py`)

| Constant      | Value | Meaning                                                          |
|---------------|-------|------------------------------------------------------------------|
| `num_rounds`  | 300   | rounds played by each participant                                |
| `upside`      | 63    | *b*: Option B payoff when the opponent also chooses B            |
| `downside`    | 47    | *a*: Option B payoff when the opponent chooses A                 |
| `breaks`      | 51, 101, 151, 201, 251 | rounds at which a rest break is shown (6 blocks of 50) |

For each participant, the round that determines the bonus payment is drawn uniformly at
random over the 300 rounds in `creating_session` (stored as `participant.vars['paid_round']`)
and revealed only on the final `Results` page.


## Payoffs and the generation script

`exp2/payoffs_high.py` contains the **exact** sequences of θ presented to participants during
data collection, stored as `matrix_high`, a list of 300 lists of 300 integer-valued strings.

`generate_payoffs.py` documents how those sequences were produced (i.i.d. draws from
Normal(55, 400), rounded and truncated to [11, 99]). **Re-running it does not overwrite the
original data**: it writes a fresh random draw to `exp2/payoffs_high_new.py` so that
`payoffs_high.py` always preserves the values actually shown to subjects.
