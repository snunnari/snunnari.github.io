"""
Generate the random sequences of theta shown to participants in Experiment 1 (the
human-vs-human coordination game) of Frydman and Nunnari, "Coordination with Cognitive
Noise."

In every round, Option A delivers a sure number of points, theta, which is the only
feature of the game that varies across rounds. Participants are randomly split between two
between-subjects conditions (the assignment is done in exp1/models.py by participant id
parity): a high-volatility condition with theta ~ Normal(55, 400) and a low-volatility
condition with theta ~ Normal(55, 20). Each of 300 potential participants per condition is
assigned an independent sequence of 300 integer values of theta, rounded to the nearest
integer and truncated to [11, 99] (values outside the range are re-drawn).

The exact sequences used during data collection are stored in exp1/payoffs_high.py
(`matrix_high`) and exp1/payoffs_low.py (`matrix_low`). This script documents how they were
produced. Re-running it draws a NEW random sample and writes it to
exp1/payoffs_high_new.py / exp1/payoffs_low_new.py; it does NOT overwrite the sequences that
were actually shown to participants.

Requires numpy. Run from the project root:  python generate_payoffs.py
"""

import os
import numpy as np

SUBJECTS = 300          # independent sequences per condition
ROUNDS = 300
MEAN = 55
SD_HIGH = np.sqrt(400)  # high-volatility condition (variance 400)
SD_LOW = np.sqrt(20)    # low-volatility condition (variance 20)
LOWER, UPPER = 11, 99


def draw_matrix(sd):
    matrix = []
    for s in range(SUBJECTS):
        trials = []
        while len(trials) < ROUNDS:
            theta = int(np.round(np.random.normal(loc=MEAN, scale=sd)))
            if LOWER <= theta <= UPPER:
                trials.append(theta)
        matrix.append(trials)
    return matrix


def write_module(path, varname, matrix):
    # Same module format as exp1/payoffs_high.py / exp1/payoffs_low.py (values as strings).
    formatted = [[str(theta) for theta in row] for row in matrix]
    with open(path, 'w') as f:
        f.write(varname + ' = ' + repr(formatted) + '\n')


here = os.path.dirname(os.path.abspath(__file__))
write_module(os.path.join(here, 'exp1', 'payoffs_high_new.py'), 'matrix_high', draw_matrix(SD_HIGH))
write_module(os.path.join(here, 'exp1', 'payoffs_low_new.py'), 'matrix_low', draw_matrix(SD_LOW))

print('Wrote fresh draws to exp1/payoffs_high_new.py and exp1/payoffs_low_new.py')
print('The sequences actually used in the experiment remain in exp1/payoffs_high.py / exp1/payoffs_low.py.')
