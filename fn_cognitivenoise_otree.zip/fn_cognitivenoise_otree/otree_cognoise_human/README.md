# Experiment 1 (Human vs Human) — oTree software

This folder contains the [oTree](https://www.otree.org) software used to run **Experiment 1
(the human-vs-human coordination game)** in:

> Cary Frydman and Salvatore Nunnari, "Coordination with Cognitive Noise."

This project contains a single oTree app, **`exp1`**, run through the session configuration `exp1`. 


## What the experiment does

On each of 300 rounds, a subject plays the one-shot 2×2 coordination game of the paper
against **another (anonymous) participant**. The two actions are labeled neutrally as
**Option A** and **Option B** (their left/right screen position is randomized each round):

- **Option A** ("Not Invest") pays a sure number of points, *θ*, displayed on screen.
- **Option B** ("Invest") pays **47** points if the other participant chooses A and **63**
  points if the other participant chooses B (the parameters *a* = 47 and *b* = 63).

Subjects are randomly split between two **volatility conditions** (between subjects, by
participant id parity): odd participants see values of *θ* drawn from a high-volatility
distribution, *N*(55, 400); even participants see a low-volatility distribution, *N*(55,
20). Sequences are pre-generated and stored in `exp1/payoffs_high.py` and
`exp1/payoffs_low.py`. Subjects receive no feedback between rounds. The task begins with
instructions and a three-question comprehension quiz (which must be answered correctly to
proceed) and pauses for a rest break every 50 rounds.

**Asynchronous matching and payment.** Subjects do not interact in real time: each plays
all 300 rounds alone, seeing their own independent sequence of *θ* values. As described in
the paper, subjects were matched into pairs and the coordination outcomes and earnings were
determined **offline, after all subjects had completed the study** (pairing two subjects
requires matching them on a common value of *θ*). For each subject, one of their 300
rounds is drawn uniformly at random to determine the bonus, and the selected decision is
shown on the final `Results` page. This offline, no-feedback design is why the app has no real-time grouping (`players_per_group = None`).

### Flow of the app (page sequence)

`Welcome → Instructions_1 → Instructions_2 → QuizQuestions → (QuizAnswersWrong) →
QuizAnswersRight → [ Cross → Decision ] × 300 → Results`

The instruction, quiz, and result pages are shown only on the first/last round; `Cross` is
a fixation screen shown before each decision and also serves as the rest break between the
six blocks of 50 rounds. `QuizAnswersWrong` is shown only if the quiz is failed.


## Requirements

- **Python 3.8** (the study ran under 3.8.10)
- **oTree 3.3.11** (the legacy, class-based oTree API — this app is not compatible with oTree 5+)
- **numpy** (only needed if you want to re-run `generate_payoffs.py`)

`requirements.txt` also lists `psycopg2` (PostgreSQL) and `sentry-sdk` (error monitoring),
used for the original cloud deployment; neither is needed to run locally with SQLite.

### Creating the environment

With conda (recommended):

```bash
conda create -n cognoise-otree3 python=3.8
conda activate cognoise-otree3
pip install otree==3.3.11 numpy
```

Or with a plain virtual environment:

```bash
python3.8 -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install otree==3.3.11 numpy
```


## Running the experiment

These steps deploy the app on your **local machine**, which is all you need to inspect or
reproduce the experiment. For the actual data collection the app was hosted on an **online
server** (in our case, Heroku); the `Procfile` and `runtime.txt` files are that cloud
configuration.

From this folder, with the environment activated:

```bash
otree devserver
```

Then open <http://localhost:8000> and start the **`exp1`** session (via Demo, via Sessions,
or via one of the predefined Rooms in `settings.py`).

To verify that the app installs and runs correctly, run the automated playthrough:

```bash
otree test exp1
```

This sends bots through the whole experiment (instructions, quiz, and all 300 rounds) and
should finish with `Bots completed session`. The bot is used only for testing.

> If `otree devserver` reports a database error on first run, delete `db.sqlite3` (if
> present) and start it again; do not run `otree resetdb` immediately before `devserver`.


## Project structure

```
exp1/                        the oTree app implementing Experiment 1
  models.py                 Constants, Subsession, Group, Player; assigns each
                            participant to a condition and a 300-round theta sequence
  pages.py                  page logic and the page sequence
  payoffs_high.py           matrix_high: 300 x 300 theta values, high-volatility condition
  payoffs_low.py            matrix_low:  300 x 300 theta values, low-volatility condition
  templates/exp1/            one HTML template per page
  tests.py                  bot used by `otree test exp1`
  _builtin/                 oTree-generated helper (do not edit)
generate_payoffs.py         documents how the theta sequences were drawn
settings.py                 session config (exp1), rooms, currency, admin
manage.py                   oTree/Django entry point
requirements.txt            packages used for the original deployment
runtime.txt, Procfile       configuration for cloud (Heroku) deployment
_static/, _templates/       project-wide static assets and the base page template
LICENSE                     license (MIT, from the oTree project template)
```

### Key parameters (in `exp1/models.py`)

| Constant      | Value | Meaning                                                          |
|---------------|-------|------------------------------------------------------------------|
| `num_rounds`  | 300   | rounds played by each participant                                |
| `upside`      | 63    | *b*: Option B payoff when the other participant also chooses B    |
| `downside`    | 47    | *a*: Option B payoff when the other participant chooses A         |
| `breaks`      | 51, 101, 151, 201, 251 | rounds at which a rest break is shown (6 blocks of 50) |

For each participant, the round that determines the bonus is drawn uniformly at random over
the 300 rounds in `creating_session` (stored as `participant.vars['paid_round']`).


## Payoffs and the generation script

`exp1/payoffs_high.py` and `exp1/payoffs_low.py` contain the **exact** sequences of *θ*
presented to participants during data collection (`matrix_high` / `matrix_low`, each a
list of 300 lists of 300 integer-valued strings).

`generate_payoffs.py` documents how those sequences were produced (i.i.d. draws from
*N*(55, 400) and *N*(55, 20), rounded and truncated to [11, 99]). **Re-running it does not
overwrite the original data**: it writes fresh draws to `exp1/payoffs_high_new.py` /
`exp1/payoffs_low_new.py`.
