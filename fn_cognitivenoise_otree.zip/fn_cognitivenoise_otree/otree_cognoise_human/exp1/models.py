from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

from . import payoffs_low
from . import payoffs_high
import random
import math


author = 'Cary Frydman and Salvatore Nunnari'

doc = """
Experiment 1 (Human vs Human) in Frydman and Nunnari, "Coordination with Cognitive
Noise." Subjects play 300 one-shot 2x2 coordination games against another, anonymous
participant (matched asynchronously, after data collection). Each subject is randomly
assigned to a high- or low-volatility condition that governs the distribution of the
per-round payoff theta.
"""

class Constants(BaseConstants):
    name_in_url = 'exp1'
    players_per_group = None
    num_rounds = 300

    upside = 63 # earnings if B and opponent chooses B
    downside = 47 # earnings if B and opponent chooses A

    #breaks = [] # no pause
    #breaks = [math.ceil(num_rounds / 2) + 1]  # pause after 50% of total trials
    breaks = [i for i in range(51, num_rounds, 50)] # pause every 50 trials
    #breaks = [i for i in range(46, num_rounds, 45)] # pause every 45 trials


class Subsession(BaseSubsession):

    def creating_session(self):
        # The integer values of theta shown to each participant on each of the 300 rounds
        # are pre-generated and stored in payoffs_high.py (matrix_high) and payoffs_low.py
        # (matrix_low). See generate_payoffs.py for how the sequences were drawn.

        if self.round_number == 1:
            amounts_low = payoffs_low.matrix_low
            amounts_high = payoffs_high.matrix_high

            for p in self.get_players():
                # assign all participants to high volatility condition
                #p.participant.vars['random_amounts'] = amounts_high[p.id_in_group]
                # assign all participants to low volatility condition
                #p.participant.vars['random_amounts'] = amounts_low[p.id_in_group]
                if p.id_in_group % 2 == 1: # if id_in_group is odd, assign to high volatility treatment
                    p.participant.vars['random_amounts'] = amounts_high[int((p.id_in_group+1)/2-1)]
                else: # if id_in_group is even, assign to low volatility treatment
                    p.participant.vars['random_amounts'] = amounts_low[int(p.id_in_group/2-1)]

                # one round, drawn uniformly at random for each participant, determines the
                # bonus (the matched partner is resolved offline, on the same value of theta)
                p.participant.vars['paid_round'] = random.randint(1, Constants.num_rounds)

        for p in self.get_players():
            p.number_on_left = random.choice([True, False])
            p.number = int(p.participant.vars['random_amounts'][self.round_number - 1])


class Group(BaseGroup):
    pass

class Player(BasePlayer):
    quiz_answer_1 = models.StringField(
            choices=[['1', 'I earn 47 points and my opponent earns 63 points'],
            ['2', 'I earn 47 points and my opponent earns 49 points'],
            ['3', 'I earn 63 points and my opponent earns 47 points'],
            ['4', 'I earn 63 points and my opponent earns 49 points']],
            widget=widgets.RadioSelect,
            label=''''''
    )

    quiz_answer_2 = models.StringField(
            choices=[['1','I earn 51 points and my opponent earns 47 points' ],
            ['2', 'I earn 47 points and my opponent earns 51 points'],
            ['3', 'We both earn 51 points'],
            ['4', 'We both earn 47 points']],
            widget=widgets.RadioSelect,
            label=''''''
    )

    quiz_answer_3 = models.StringField(
                choices=[['1', 'I earn 47 points and my opponent earns 63 points'],
                ['2', 'I earn 63 points and my opponent earns 47 points'],
                ['3', 'We both earn 48 points'],
                ['4', 'We both earn 63 points']],
                widget=widgets.RadioSelect,
                label=''''''
        )

    number = models.IntegerField()
    number_on_left = models.BooleanField()
    decision = models.StringField()
    dectime = models.FloatField(blank=True)
