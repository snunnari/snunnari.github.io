from otree.api import Currency as c, currency_range, Submission
from . import pages
from ._builtin import Bot
from .models import Constants
import random


class PlayerBot(Bot):
    """Automated playthrough used by `otree test exp1` to check the app runs.

    Reads the instructions, answers the comprehension quiz correctly, and then plays each
    of the 300 rounds by choosing a random option. Used only for automated testing; it
    plays no role in data collection.
    """

    def play_round(self):
        if self.round_number == 1:
            yield pages.Welcome
            yield pages.Instructions_1
            yield pages.Instructions_2
            # Correct answers to the three comprehension questions.
            yield pages.QuizQuestions, dict(
                quiz_answer_1='2', quiz_answer_2='3', quiz_answer_3='4'
            )
            # QuizAnswersWrong is not displayed because the answers are correct.
            yield pages.QuizAnswersRight
        yield pages.Cross
        yield pages.Decision, dict(decision=random.choice(['Left', 'Right']), dectime=1.23)
        if self.round_number == Constants.num_rounds:
            # Results is the terminal page (it shows the completion link, no button).
            yield Submission(pages.Results, check_html=False)
